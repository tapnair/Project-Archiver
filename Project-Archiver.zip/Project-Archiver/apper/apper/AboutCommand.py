"""
AboutCommand.py
=========================================================
**Not Implemented Yet** Python module for creating
standard "about" command for an Apper Fusion 360 add-in

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
:copyright: (c) 2019 by Patrick Rainsberry.
:license: Apache 2.0, see LICENSE for more details.

"""
pass
